import 'package:capstone/screen/auth/login_page.dart';
import 'package:capstone/screen/myhome.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      // 화면이동을 위해 route를 사용
      initialRoute: "/login", // 초기 경로 설정
      routes: {
        // 경로 목록
        "/login": (context) => LoginPage(),
        "/home": (context) => MyHome(),
      },
    );
  }
}
