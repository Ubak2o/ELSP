import 'package:flutter/material.dart';
import 'package:capstone/size.dart';

class CustomTextFormField extends StatelessWidget {
  final String text;
  final TextEditingController controller; // 새로운 controller 정의
  const CustomTextFormField(this.text, {required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(text),
        SizedBox(
          height: small_gap,
        ),
        TextFormField(
          validator: (value) => value!.isEmpty ? "필수항목입니다" : null,
          obscureText: text == "Password" ? true : false,
          controller: controller, // 정의한 controller 사용
          decoration: InputDecoration(
            hintText: "Enter $text.",
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(20),
            ),
          ),
        )
      ],
    );
  }
}
