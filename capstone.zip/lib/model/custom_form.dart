import 'package:flutter/material.dart';
import 'package:capstone/model/custom_text_form_field.dart';
import 'package:capstone/size.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;

class CustomForm extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          CustomTextFormField("Username", controller: usernameController),
          SizedBox(
            height: medium_gap,
          ),
          CustomTextFormField("Password", controller: passwordController),
          SizedBox(
            height: large_gap,
          ),
          TextButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                // 로그인 요청 보내기
                final response = await http.post(
                  Uri.parse('http://127.0.0.1:8000/users/login/'),
                  headers: {'Content-Type': 'application/json'},
                  body: jsonEncode({
                    'username': usernameController.text,
                    'password': passwordController.text,
                  }),
                );

                if (response.statusCode == 200) {
                  // 로그인 성공
                  final Map<String, dynamic> data = json.decode(response.body);
                  final String accessToken = data['access'];
                  final String refreshToken = data['refresh'];

                  // 이제 accessToken과 refreshToken을 사용하여 필요한 작업을 수행할 수 있습니다.
                  // 예를 들어, 사용자 토큰을 저장하고 다음 화면으로 이동하는 등의 작업이 가능합니다.
                  print('Login successful');
                  print('Access Token: $accessToken');
                  print('Refresh Token: $refreshToken');

                  // 여기에서 적절한 작업을 수행하세요.
                  print("로그인 성공");
                  Navigator.pushNamed(context, '/home');
                } else {
                  // 로그인 실패
                  print('Login failed');
                }
              }
            },
            child: Text("Login"),
          )
        ],
      ),
    );
  }
}
